#pragma once
#include "raylib.h"
#include <string>
#include <vector>
#include <map>

struct AnimClip {
    std::vector<Texture2D> frames;
    float frameDuration;
    bool loop;
};

class AnimationManager {
public:
    AnimationManager();
    ~AnimationManager();

    bool LoadSheet(const std::string& path, int frameWidth, int frameHeight);
    void AddClip(const std::string& name, int startFrame, int endFrame, float fps, bool loop);
    void Play(const std::string& name, bool restart = false);
    void Update(float dt);
    void Draw(Vector2 position, bool flipX = false, float scale = 1.0f, Color tint = WHITE) const;

private:
    std::map<std::string, AnimClip> clips;
    std::string currentAnim;
    int currentFrameIndex;
    float timer;
    bool isPlaying;
};

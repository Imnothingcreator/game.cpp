#pragma once

// Central tuning constants for KBDworld.
// Physics multipliers and cycle timing will be added here as those systems land.
namespace Config {

// ---- Window / timing -------------------------------------------------------
inline constexpr int         ScreenWidth   = 1280;
inline constexpr int         ScreenHeight  = 720;
inline constexpr int         TargetFPS     = 60;
inline constexpr const char* WindowTitle   = "KBDworld";

// Largest delta time the simulation will accept. Protects animation and
// movement from huge jumps after a window drag, breakpoint or load hitch.
inline constexpr float       MaxDeltaTime  = 1.0f / 20.0f;

// ---- Slugcat sprite sheet --------------------------------------------------
// Frames are read row-major (left to right, then top to bottom).
// Adjust these to match your actual art.
inline constexpr const char* SlugcatSheetPath   = "assets/sprites/slugcat.png";
inline constexpr int         SlugcatFrameWidth  = 64;
inline constexpr int         SlugcatFrameHeight = 64;

inline constexpr int   SlugcatIdleFirstFrame = 0;
inline constexpr int   SlugcatIdleFrameCount = 4;
inline constexpr float SlugcatIdleFPS        = 6.0f;

inline constexpr int   SlugcatRunFirstFrame  = 4;
inline constexpr int   SlugcatRunFrameCount  = 8;
inline constexpr float SlugcatRunFPS         = 14.0f;

inline constexpr float SpriteScale           = 2.0f;

// ---- Demo movement (temporary until Player.cpp owns this) ------------------
inline constexpr float DemoMoveSpeed = 260.0f;   // pixels per second
inline constexpr float DemoGroundY   = 600.0f;

} // namespace Config

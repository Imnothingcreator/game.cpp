#ifndef LIZARD_H
#define LIZARD_H

#include "raylib.h"
#include <vector>
#include <string>
#include <unordered_map>

enum class LizardState {
    PATROL,
    CHASE,
    ATTACK
};

class Lizard {
private:
    std::unordered_map<std::string, std::vector<Texture2D>> animations;
    std::string currentAnimState;
    int currentFrame;
    float frameTimer;
    float frameSpeed;
    float scale;

    LizardState currentState;
    float patrolTimer;
    float patrolDuration;
    float moveSpeed;
    bool facingLeft;
    float detectionRange;
    float attackRange;
    float attackTimer;

    void LoadAnimations();

public:
    Vector2 position;

    Lizard(Vector2 startPos);
    ~Lizard();

    // Prevent copying
    Lizard(const Lizard&) = delete;
    Lizard& operator=(const Lizard&) = delete;

    // Updated to accept player position by reference and groundLevel for respawning
    void Update(float dt, Vector2& playerPos, float groundLevel);
    void Render() const;
};

#endif // LIZARD_H

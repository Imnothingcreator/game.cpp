#include "Lizard.h"
#include <iostream>
#include <filesystem>
#include <algorithm>
#include <cmath>

namespace fs = std::filesystem;

Lizard::Lizard(Vector2 startPos) {
    position = startPos;
    currentFrame = 0;
    frameTimer = 0.0f;
    frameSpeed = 0.12f;
    scale = 1.4f;

    currentState = LizardState::PATROL;
    currentAnimState = "WALK";
    patrolTimer = 0.0f;
    patrolDuration = 3.0f;
    moveSpeed = 1.5f;
    facingLeft = false;
    detectionRange = 350.0f;
    attackRange = 50.0f;
    attackTimer = 0.0f;
    hasTextures = false;

    LoadAnimations();
}

Lizard::~Lizard() {
    for (auto& pair : animations) {
        for (auto& tex : pair.second) {
            if (tex.id != 0) {
                UnloadTexture(tex);
            }
        }
    }
}

void Lizard::Reset(Vector2 startPos) {
    position = startPos;
    currentState = LizardState::PATROL;
    currentAnimState = "WALK";
    patrolTimer = 0.0f;
    attackTimer = 0.0f;
    moveSpeed = 1.5f;
    facingLeft = false;
}

void Lizard::LoadAnimations() {
    std::string targetFolder = "";

    if (fs::exists("assets")) {
        for (const auto& entry : fs::recursive_directory_iterator("assets")) {
            if (entry.is_directory()) {
                std::string dirName = entry.path().filename().string();
                std::transform(dirName.begin(), dirName.end(), dirName.begin(), ::tolower);
                if (dirName.find("lizard") != std::string::npos) {
                    targetFolder = entry.path().string();
                    break;
                }
            }
        }
    }

    if (targetFolder.empty()) {
        if (fs::exists("assets/backgrounds/lizard")) targetFolder = "assets/backgrounds/lizard";
        else if (fs::exists("assets/lizard")) targetFolder = "assets/lizard";
        else if (fs::exists("assets/enemies/lizard")) targetFolder = "assets/enemies/lizard";
    }

    if (targetFolder.empty()) {
        hasTextures = false;
        return;
    }

    std::vector<std::string> filePaths;
    for (const auto& entry : fs::directory_iterator(targetFolder)) {
        if (entry.is_regular_file()) {
            std::string ext = entry.path().extension().string();
            std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
            if (ext == ".png" || ext == ".jpg" || ext == ".jpeg") {
                filePaths.push_back(entry.path().string());
            }
        }
    }
    std::sort(filePaths.begin(), filePaths.end());

    std::vector<Texture2D> texList;
    for (const auto& fp : filePaths) {
        Texture2D tex = LoadTexture(fp.c_str());
        if (tex.id != 0) {
            texList.push_back(tex);
        }
    }

    if (!texList.empty()) {
        animations["WALK"] = texList;
        animations["ATTACK"] = texList;
        hasTextures = true;
    } else {
        hasTextures = false;
    }

    currentAnimState = "WALK";
}

void Lizard::Update(float dt, Vector2& playerPos, float groundLevel) {
    (void)groundLevel;
    float distToPlayerX = playerPos.x - position.x;
    float absDist = std::abs(distToPlayerX);

    std::string desiredAnim = "WALK";

    if (absDist <= attackRange) {
        currentState = LizardState::ATTACK;
        desiredAnim = "ATTACK";
        moveSpeed = 0.0f;
        facingLeft = (distToPlayerX < 0);
        attackTimer += dt;
    } 
    else if (absDist <= detectionRange) {
        currentState = LizardState::CHASE;
        desiredAnim = "WALK";
        moveSpeed = 2.5f;
        facingLeft = (distToPlayerX < 0);
        attackTimer = 0.0f;
    } 
    else {
        currentState = LizardState::PATROL;
        desiredAnim = "WALK";
        moveSpeed = 1.0f;
        attackTimer = 0.0f;

        patrolTimer += dt;
        if (patrolTimer >= patrolDuration) {
            patrolTimer = 0.0f;
            facingLeft = !facingLeft;
        }
    }

    if (hasTextures) {
        if (currentAnimState != desiredAnim) {
            if (animations.find(desiredAnim) != animations.end()) {
                currentAnimState = desiredAnim;
                currentFrame = 0;
                frameTimer = 0.0f;
            }
        }

        auto it = animations.find(currentAnimState);
        if (it != animations.end() && !it->second.empty()) {
            frameTimer += dt;
            if (frameTimer >= frameSpeed) {
                frameTimer = 0.0f;
                currentFrame = (currentFrame + 1) % it->second.size();
            }
        }
    }

    if (currentState != LizardState::ATTACK || attackTimer > 0.8f) {
        if (facingLeft) {
            position.x -= moveSpeed;
        } else {
            position.x += moveSpeed;
        }
    }

    if (position.x < 80.0f) {
        position.x = 80.0f;
        facingLeft = false;
    } else if (position.x > 1200.0f) {
        position.x = 1200.0f;
        facingLeft = true;
    }
}

void Lizard::Render() const {
    if (!hasTextures || animations.find(currentAnimState) == animations.end() || animations.at(currentAnimState).empty()) {
        Color lizardColor = (currentState == LizardState::ATTACK) ? RED : (currentState == LizardState::CHASE ? ORANGE : LIME);
        DrawRectanglePro(
            { position.x, position.y - 25.0f, 60.0f, 30.0f },
            { 30.0f, 30.0f },
            0.0f,
            lizardColor
        );
        float eyeOffset = facingLeft ? -15.0f : 15.0f;
        DrawCircle((int)(position.x + eyeOffset), (int)(position.y - 32.0f), 4.0f, YELLOW);
        return;
    }

    const std::vector<Texture2D>& frames = animations.at(currentAnimState);
    Texture2D tex = frames[currentFrame % frames.size()];

    float targetWidth = 100.0f * scale;
    float targetHeight = 50.0f * scale;
    Vector2 origin = { targetWidth / 2.0f, targetHeight };

    Rectangle sourceRec = {
        0.0f,
        0.0f,
        (float)(facingLeft ? -tex.width : tex.width),
        (float)tex.height
    };

    Rectangle destRec = {
        position.x,
        position.y,
        targetWidth,
        targetHeight
    };

    DrawTexturePro(tex, sourceRec, destRec, origin, 0.0f, WHITE);
}

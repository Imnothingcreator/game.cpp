#include "raylib.h"
#include "AnimationManager.h"
#include "Lizard.h"
#include <iostream>
#include <vector>
#include <string>

struct Vine {
    Rectangle bounds;
    Texture2D texture;
};

struct Platform {
    Rectangle bounds;
    Color color;
};

enum class GameState {
    PLAYING,
    GAME_OVER
};

int main() {
    const int screenWidth = 1280;
    const int screenHeight = 720;
    InitWindow(screenWidth, screenHeight, "KBDworld - Bloodbath Moon");
    SetTargetFPS(60);

    Texture2D background = LoadTexture("assets/backgrounds/background.png");

    // Vines matching your Bloodbath Moon layout
    std::vector<Vine> vines = {
        { { 240.0f, 340.0f, 20.0f, 320.0f }, LoadTexture("assets/backgrounds/vine(1).png") },
        { { 400.0f, 280.0f, 20.0f, 380.0f }, LoadTexture("assets/backgrounds/vine(2).png") },
        { { 600.0f, 320.0f, 20.0f, 340.0f }, LoadTexture("assets/backgrounds/vine(1).png") },
        { { 750.0f, 300.0f, 20.0f, 360.0f }, LoadTexture("assets/backgrounds/vine(2).png") },
        { { 900.0f, 280.0f, 20.0f, 380.0f }, LoadTexture("assets/backgrounds/vine(1).png") },
        { { 1050.0f, 320.0f, 20.0f, 340.0f }, LoadTexture("assets/backgrounds/vine(2).png") }
    };

    // Platforms matching your level design
    std::vector<Platform> platforms = {
        { { 80.0f, 540.0f, 100.0f, 16.0f }, DARKGRAY },
        { { 180.0f, 500.0f, 80.0f,  16.0f }, DARKGRAY },
        { { 280.0f, 460.0f, 120.0f, 16.0f }, DARKGRAY },
        { { 430.0f, 400.0f, 140.0f, 16.0f }, DARKGRAY },
        { { 340.0f, 360.0f, 90.0f,  16.0f }, DARKGRAY },
        { { 520.0f, 480.0f, 100.0f, 16.0f }, DARKGRAY },
        { { 660.0f, 420.0f, 110.0f, 16.0f }, DARKGRAY },
        { { 800.0f, 380.0f, 130.0f, 16.0f }, DARKGRAY },
        { { 960.0f, 440.0f, 120.0f, 16.0f }, DARKGRAY },
        { { 1100.0f, 390.0f, 90.0f, 16.0f }, DARKGRAY }
    };

    AnimationManager slugcat;
    slugcat.LoadSheet("", 0, 0);
    slugcat.Play("IDLE", true);

    const float groundLevel = 620.0f;
    Vector2 playerSpawn = { 120.0f, groundLevel };
    Vector2 lizardSpawn = { 950.0f, groundLevel };

    Vector2 playerPos = playerSpawn;
    Vector2 playerVel = { 0.0f, 0.0f };
    Lizard lizard(lizardSpawn);

    float walkSpeed = 3.5f;
    float runSpeed = 6.0f;
    float climbSpeed = 3.0f;
    float jumpForce = -11.5f;
    float gravity = 0.5f;
    
    bool isGrounded = true;
    bool isClimbing = false;
    bool faceLeft = false;
    std::string currentAnimState = "IDLE";

    GameState gameState = GameState::PLAYING;
    Rectangle restartButton = { (float)screenWidth / 2.0f - 110.0f, (float)screenHeight / 2.0f + 40.0f, 220.0f, 50.0f };

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();

        if (gameState == GameState::PLAYING) {
            // --- STRICT VINE CLIMBING CHECK ---
            isClimbing = false;
            for (const auto& vine : vines) {
                // Strict X proximity and vertical bounding check
                bool nearVineX = (playerPos.x >= vine.bounds.x - 15.0f) && (playerPos.x <= vine.bounds.x + vine.bounds.width + 15.0f);
                bool overlappingVineY = (playerPos.y - 70.0f <= vine.bounds.y + vine.bounds.height) && (playerPos.y >= vine.bounds.y);

                if (nearVineX && overlappingVineY) {
                    if (IsKeyDown(KEY_W) || IsKeyDown(KEY_S) || IsKeyDown(KEY_UP) || IsKeyDown(KEY_DOWN)) {
                        isClimbing = true;
                    }
                }
            }

            bool isMoving = false;
            std::string desiredAnim = "IDLE";

            if (isClimbing) {
                playerVel.y = 0.0f;
                isGrounded = false;

                if (IsKeyDown(KEY_W) || IsKeyDown(KEY_UP)) { playerPos.y -= climbSpeed; isMoving = true; }
                if (IsKeyDown(KEY_S) || IsKeyDown(KEY_DOWN)) { playerPos.y += climbSpeed; isMoving = true; }
                desiredAnim = "CLIMB";
            } 
            else {
                bool isRunning = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
                float currentSpeed = isRunning ? runSpeed : walkSpeed;

                if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT)) { playerPos.x -= currentSpeed; faceLeft = true; isMoving = true; }
                if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT)) { playerPos.x += currentSpeed; faceLeft = false; isMoving = true; }

                if ((IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_W)) && isGrounded) {
                    playerVel.y = jumpForce;
                    isGrounded = false;
                }

                // --- ROBUST GRAVITY & PLATFORM PHYSICS ---
                playerVel.y += gravity;
                playerPos.y += playerVel.y;

                isGrounded = false; // Reset grounded state every frame before checking collisions

                // Ground level collision
                if (playerPos.y >= groundLevel) {
                    playerPos.y = groundLevel;
                    playerVel.y = 0.0f;
                    isGrounded = true;
                }

                // Platform collisions (only standable on top of platforms when falling)
                for (const auto& plat : platforms) {
                    bool withinPlatX = (playerPos.x >= plat.bounds.x - 12.0f) && (playerPos.x <= plat.bounds.x + plat.bounds.width + 12.0f);
                    float prevFeetY = playerPos.y - playerVel.y;

                    if (withinPlatX && playerVel.y >= 0.0f && prevFeetY <= plat.bounds.y + 4.0f && playerPos.y >= plat.bounds.y - 4.0f) {
                        playerPos.y = plat.bounds.y;
                        playerVel.y = 0.0f;
                        isGrounded = true;
                        break;
                    }
                }

                if (!isGrounded) {
                    desiredAnim = (playerVel.y < 0.0f) ? "JUMP" : "FALL";
                } else if (isMoving) {
                    desiredAnim = isRunning ? "RUN" : "WALK";
                } else {
                    desiredAnim = "IDLE";
                }
            }

            if (currentAnimState != desiredAnim) {
                currentAnimState = desiredAnim;
                slugcat.Play(currentAnimState, false);
            }

            slugcat.Update(dt);
            lizard.Update(dt, playerPos, groundLevel);

            // --- DEATH CHECK ---
            float playerLizardDist = std::abs(lizard.position.x - playerPos.x);
            if (std::abs(lizard.position.y - playerPos.y) < 50.0f && playerLizardDist < 35.0f) {
                gameState = GameState::GAME_OVER;
            }

        } else if (gameState == GameState::GAME_OVER) {
            Vector2 mousePos = GetMousePosition();
            bool clickedButton = CheckCollisionPointRec(mousePos, restartButton) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
            bool pressedKey = IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_SPACE);

            if (clickedButton || pressedKey) {
                playerPos = playerSpawn;
                playerVel = { 0.0f, 0.0f };
                lizard.Reset(lizardSpawn);
                gameState = GameState::PLAYING;
            }
        }

        // --- RENDER PASS ---
        BeginDrawing();
        ClearBackground(BLACK);

        if (background.id != 0) {
            DrawTexture(background, 0, 0, WHITE);
        }

        DrawRectangle(0, (int)groundLevel, screenWidth, 100, DARKGRAY);

        for (const auto& plat : platforms) {
            DrawRectangleRec(plat.bounds, plat.color);
        }

        for (const auto& vine : vines) {
            DrawTexturePro(
                vine.texture,
                { 0.0f, 0.0f, (float)vine.texture.width, (float)vine.texture.height },
                vine.bounds,
                { 0.0f, 0.0f },
                0.0f,
                WHITE
            );
        }

        DrawText("60 FPS", 20, 20, 20, LIME);
        DrawText("LEVEL 1: Bloodbath Moon", 20, 45, 18, RED);
        DrawText("CONTROLS: A/D to Move | W/S or Up/Down on Vines to Climb | SPACE to Jump", 20, 70, 14, LIGHTGRAY);

        lizard.Render();
        slugcat.Draw(playerPos, faceLeft, 1.0f, WHITE);

        // --- GAME OVER OVERLAY ---
        if (gameState == GameState::GAME_OVER) {
            DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.8f));

            const char* titleText = "YOU DIED";
            int titleWidth = MeasureText(titleText, 50);
            DrawText(titleText, screenWidth / 2 - titleWidth / 2, screenHeight / 2 - 80, 50, RED);

            const char* subText = "The bloodbath moon claims another victim...";
            int subWidth = MeasureText(subText, 20);
            DrawText(subText, screenWidth / 2 - subWidth / 2, screenHeight / 2 - 20, 20, LIGHTGRAY);

            Vector2 mousePos = GetMousePosition();
            bool hovered = CheckCollisionPointRec(mousePos, restartButton);
            DrawRectangleRec(restartButton, hovered ? MAROON : RED);
            DrawRectangleLinesEx(restartButton, 2, WHITE);

            const char* btnText = "RESTART";
            int btnWidth = MeasureText(btnText, 22);
            DrawText(btnText, (int)(restartButton.x + restartButton.width / 2 - btnWidth / 2), (int)(restartButton.y + 14), 22, WHITE);
        }

        EndDrawing();
    }

    UnloadTexture(background);
    for (auto& vine : vines) {
        UnloadTexture(vine.texture);
    }
    CloseWindow();

    return 0;
}

#include "AnimationManager.h"
#include <iostream>
#include <algorithm>

AnimationManager::AnimationManager() 
    : currentFrameIndex(0), timer(0.0f), isPlaying(false) {
}

AnimationManager::~AnimationManager() {
    for (auto& pair : clips) {
        for (auto& tex : pair.second.frames) {
            if (tex.id != 0) {
                UnloadTexture(tex);
            }
        }
    }
}

bool AnimationManager::LoadSheet(const std::string& /*path*/, int /*frameWidth*/, int /*frameHeight*/) {
    std::vector<std::string> animNames = {
        "IDLE", "WALK", "RUN", "JUMP", "FALL", "CLIMB",
        "LOOK_UP", "LOOK_DOWN", "TURN_LEFT", "TURN_RIGHT", 
        "DEATH", "HURT"
    };

    bool loadedAny = false;
    for (const auto& name : animNames) {
        std::vector<Texture2D> texFrames;
        int maxFrames = (name == "HURT") ? 6 : 8;
        
        for (int i = 0; i < maxFrames; ++i) {
            std::string framePath = "assets/sprites/cat_animations/" + name + "/" + std::to_string(i) + ".png";
            if (FileExists(framePath.c_str())) {
                Texture2D tex = LoadTexture(framePath.c_str());
                if (tex.id != 0) {
                    SetTextureFilter(tex, TEXTURE_FILTER_POINT);
                    texFrames.push_back(tex);
                }
            }
        }
        if (!texFrames.empty()) {
            AnimClip clip;
            clip.frames = texFrames;
            clip.frameDuration = 0.12f;
            clip.loop = true;
            clips[name] = clip;
            loadedAny = true;
        }
    }
    return loadedAny;
}

void AnimationManager::AddClip(const std::string& name, int /*startFrame*/, int /*endFrame*/, float fps, bool loop) {
    if (clips.find(name) == clips.end()) {
        std::vector<Texture2D> texFrames;
        int maxFrames = (name == "HURT") ? 6 : 8;

        for (int i = 0; i < maxFrames; ++i) {
            std::string framePath = "assets/sprites/cat_animations/" + name + "/" + std::to_string(i) + ".png";
            if (FileExists(framePath.c_str())) {
                Texture2D tex = LoadTexture(framePath.c_str());
                if (tex.id != 0) {
                    SetTextureFilter(tex, TEXTURE_FILTER_POINT);
                    texFrames.push_back(tex);
                }
            }
        }
        AnimClip clip;
        clip.frames = texFrames;
        clip.frameDuration = (fps > 0.0f) ? (1.0f / fps) : 0.12f;
        clip.loop = loop;
        clips[name] = clip;
    } else {
        clips[name].frameDuration = (fps > 0.0f) ? (1.0f / fps) : 0.12f;
        clips[name].loop = loop;
    }
}

void AnimationManager::Play(const std::string& name, bool restart) {
    if (clips.find(name) != clips.end()) {
        if (currentAnim != name || restart) {
            currentAnim = name;
            currentFrameIndex = 0;
            timer = 0.0f;
            isPlaying = true;
        }
    }
}

void AnimationManager::Update(float dt) {
    if (!isPlaying || currentAnim.empty() || clips.find(currentAnim) == clips.end()) return;

    const AnimClip& clip = clips[currentAnim];
    if (clip.frames.empty()) return;

    timer += dt;
    if (timer >= clip.frameDuration) {
        timer = 0.0f;
        currentFrameIndex++;
        if (currentFrameIndex >= static_cast<int>(clip.frames.size())) {
            if (clip.loop) {
                currentFrameIndex = 0;
            } else {
                currentFrameIndex = static_cast<int>(clip.frames.size()) - 1;
                isPlaying = false;
            }
        }
    }
}

void AnimationManager::Draw(Vector2 position, bool flipX, float scale, Color tint) const {
    if (currentAnim.empty() || clips.find(currentAnim) == clips.end()) return;

    const AnimClip& clip = clips.at(currentAnim);
    if (clip.frames.empty() || currentFrameIndex < 0 || currentFrameIndex >= static_cast<int>(clip.frames.size())) return;

    Texture2D tex = clip.frames[currentFrameIndex];
    if (tex.id == 0) return;

    Rectangle source = { 0.0f, 0.0f, static_cast<float>(tex.width), static_cast<float>(tex.height) };
    float destWidth = static_cast<float>(tex.width) * scale;
    float destHeight = static_cast<float>(tex.height) * scale;

    Rectangle dest = {
        position.x,
        position.y,
        flipX ? -destWidth : destWidth,
        destHeight
    };

    Vector2 origin = { destWidth / 2.0f, destHeight / 2.0f };

    DrawTexturePro(tex, source, dest, origin, 0.0f, tint);
}
